{
    "Aimbot": {
        "Aimlock": true,
        "Horizontal Range": 180.0,
        "Horizontal Speed": 90.0,
        "Include Mobs": false,
        "Only Weapons": false,
        "Range": 8.0,
        "Require Click": false,
        "Vertical": true,
        "Vertical Range": 180.0,
        "Vertical Speed": 90.0,
        "enabled": false,
        "keybind": 86,
        "visible": true
    },
    "AirJump": {
        "Legacy": false,
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "AntiBot": {
        "EntityID Check": true,
        "Extra Check": true,
        "Hitbox Check": true,
        "Invisible Check": true,
        "Other Check": true,
        "Player List Check": true,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "AntiCrystal": {
        "Player -Y Level": 1.0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "AntiEffect": {
        "Blindness": true,
        "Darkness": true,
        "Jump Boost": true,
        "Levitation": true,
        "Nausea": true,
        "Night Vision": false,
        "Slow Falling": true,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "AntiImmobile": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "AntiVoid": {
        "distance": 5,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "ArmorHud": {
        "Position": {
            "X": 351.37481689453125,
            "Y": 283.70050048828125
        },
        "Vertical": false,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Arraylist": {
        "Bottom": false,
        "ClickToggle": false,
        "Color": 2,
        "Custom Color": {
            "Blue": 0.0,
            "Green": 0.4078238904476166,
            "HueX": 6.185455322265625,
            "PickerX": 0.0,
            "PickerY": 11.19091796875,
            "Red": 0.7513129711151123
        },
        "Font": 2,
        "Mode": 3,
        "Opacity": 0.6627581119537354,
        "Rainbow": 0,
        "Scale": 0.5,
        "Show Keybinds": true,
        "Show Modes": false,
        "enabled": true,
        "keybind": 0,
        "visible": true
    },
    "AutoArmor": {
        "Mode": 0,
        "enabled": false,
        "keybind": 80,
        "visible": false
    },
    "AutoClicker": {
        "CPS": 14,
        "Click Type": 0,
        "Hold": false,
        "MaxRand": 15,
        "MinRand": 12,
        "Only weapons": false,
        "RandomDelay": true,
        "Swing Sound": false,
        "enabled": false,
        "keybind": 0,
        "visible": true,
        "xJitter": 0.0,
        "yJitter": 0.0
    },
    "AutoDisconnect": {
        "Current Health": 10,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "AutoFish": {
        "Auto Rod": false,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "AutoMine": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "AutoMove": {
        "Jump": true,
        "Sprint": false,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "AutoRespawn": {
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "AutoSneak": {
        "Silent": false,
        "enabled": false,
        "keybind": 73,
        "visible": true
    },
    "AutoSprint": {
        "Mode": 0,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "AutoTool": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Bhop": {
        "Speed": 0.800000011920929,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Blink": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "BlockOutline": {
        "Color": {
            "Blue": 0.9936361908912659,
            "Green": 0.9936361908912659,
            "HueX": 0.0,
            "PickerX": 69.27091217041016,
            "PickerY": 0.22182464599609375,
            "Red": 0.9950705766677856
        },
        "Opacity": 0.5558523535728455,
        "Rainbow": true,
        "Style": 0,
        "Thickness": 0.42694854736328125,
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "BlockReach": {
        "enabled": false,
        "keybind": 71,
        "reach": 20.0,
        "visible": true
    },
    "BoneESP": {
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "BowAimbot": {
        "Height": 0.10000000149011612,
        "enabled": false,
        "keybind": 0,
        "predict": false,
        "silent": true,
        "visible": true,
        "visualize": true
    },
    "BowSpam": {
        "Facing Entity": false,
        "Pullback Delay": 9,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Breadcrumbs": {
        "ClearOnDisable": true,
        "StopBreadcrumbs": false,
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "CameraNoClip": {
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "Chat": {
        "Font Options": 1,
        "Prefix Options": 1,
        "Suffix Options": 0,
        "Types": 0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "ChestAura": {
        "EnderChests": false,
        "Range": 5,
        "Shulker Boxes": false,
        "Trapped Chest": false,
        "enabled": false,
        "keybind": 114,
        "visible": true
    },
    "ChestStealer": {
        "Close Delay": 4,
        "Item Per Second": 5,
        "enabled": false,
        "enhanced": true,
        "keybind": 0,
        "visible": true
    },
    "ChestVisuals": {
        "Barrels": true,
        "Chests": true,
        "Colored Shulkers": true,
        "Ender Chests": true,
        "Mode": 2,
        "Outline": true,
        "Outline Opacity": 1.0,
        "Outline Width": 1,
        "Shulkers": true,
        "Tracer Opacity": 0.5,
        "Trap Chests": true,
        "enabled": false,
        "keybind": 85,
        "visible": false
    },
    "ClickGui": {
        "Combat": {
            "isExtended": true,
            "pos": {
                "x": 12.0,
                "y": 0.0
            }
        },
        "Font": 0,
        "Gui": {
            "isExtended": true,
            "pos": {
                "x": 446.5,
                "y": 2.0
            }
        },
        "Misc": {
            "isExtended": true,
            "pos": {
                "x": 536.0,
                "y": 97.50000762939453
            }
        },
        "Movement": {
            "isExtended": true,
            "pos": {
                "x": 296.642822265625,
                "y": 0.0
            }
        },
        "Player": {
            "isExtended": true,
            "pos": {
                "x": 218.60073852539063,
                "y": 0.6162490844726563
            }
        },
        "Show Tooltips": true,
        "Style": 0,
        "Visual": {
            "isExtended": true,
            "pos": {
                "x": 110.57142639160156,
                "y": 0.0
            }
        },
        "World": {
            "isExtended": true,
            "pos": {
                "x": 388.5,
                "y": 115.49999237060547
            }
        },
        "enabled": false,
        "keybind": 45,
        "visible": true
    },
    "ClickTP": {
        "Only Hand": false,
        "Push": false,
        "enabled": false,
        "keybind": 74,
        "visible": true
    },
    "Compass": {
        "Opacity": 1.0,
        "Range": 180,
        "Show Waypoints": true,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Crasher": {
        "Crash type": 0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Criticals": {
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "CrystalAura": {
        "Attack Delay": 0,
        "Auto Place": true,
        "Multi Place": false,
        "Place Delay": 0,
        "Range": 6.0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "CustomSkin": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "CustomSky": {
        "Color": {
            "Blue": 0.1685248613357544,
            "Green": 0.11348143219947815,
            "HueX": 40.11402893066406,
            "PickerX": 21.114028930664063,
            "PickerY": 37.41637420654297,
            "Red": 0.05129295587539673
        },
        "Rainbow": false,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "DVDLogo": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Damage": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "DeathPosition": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Derp": {
        "enabled": false,
        "ihaveastroke": true,
        "keybind": 0,
        "packet mode": true,
        "visible": true
    },
    "DeviceIDSpoofer": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Disabler": {
        "Type": 0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "ESP": {
        "Color": {
            "Blue": 1.0,
            "Green": 0.0,
            "HueX": 56.11402893066406,
            "PickerX": 0.0,
            "PickerY": 0.0,
            "Red": 0.853391170501709
        },
        "ItemEsp": true,
        "MobEsp": false,
        "Rainbow": false,
        "Type": 1,
        "enabled": true,
        "keybind": 89,
        "visible": false
    },
    "EditionFaker": {
        "Edition": 7,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "ElytraFly": {
        "Speed": 0.6263564229011536,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "EntityDespawner": {
        "Armour Stands": false,
        "Boats": false,
        "Effect Cloud": false,
        "EndCrystal": false,
        "Falling Blocks": false,
        "Items": false,
        "Minecarts": false,
        "Misc": false,
        "Paintings": false,
        "Passive Mobs": true,
        "Players": false,
        "PrimedTnt": false,
        "Projectiles": false,
        "XP": false,
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "EntityFly": {
        "enabled": false,
        "keybind": 0,
        "speed": 1.0,
        "visible": true
    },
    "EntityJesus": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "EntitySpeed": {
        "Speed": 1.3794066905975342,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "FastEat": {
        "Duration": 10,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "FastLadder": {
        "Speed": 0.6000000238418579,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "FastStop": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "FastThrow": {
        "delay": 0.0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Fly": {
        "Mode": 0,
        "Speed": 0.5415835380554199,
        "enabled": false,
        "keybind": 77,
        "visible": true
    },
    "FollowPath": {
        "Assume Jesus": false,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Freecam": {
        "Show freecam pos": true,
        "Spectate player": false,
        "Speed": 0.39577561616897583,
        "enabled": false,
        "keybind": 80,
        "visible": true
    },
    "Freelook": {
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "Fucker": {
        "Barrels": false,
        "Beds": true,
        "Cakes": true,
        "Chests": true,
        "Crops": false,
        "Eggs": true,
        "Ores": false,
        "Range": 5,
        "Treasures": true,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Fullbright": {
        "Intensity": 12.0,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "GhostHand": {
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "Glide": {
        "Type": 0,
        "enabled": false,
        "keybind": 0,
        "value": 1.0,
        "visible": true
    },
    "HUD": {
        "Always Show": false,
        "Coordinates": false,
        "Font": 0,
        "Item Durability": true,
        "Main Menu": true,
        "Scale": 0.5,
        "Show CPS": false,
        "Show FPS": true,
        "Show Server IP": false,
        "Show Time": false,
        "enabled": true,
        "keybind": 0,
        "visible": true
    },
    "HealthCheck": {
        "Health Slider": 10,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "HighJump": {
        "Jump Height": 0.5,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Hitbox": {
        "Height": 2.295940399169922,
        "Include Mobs": false,
        "Width": 1.3469898700714111,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "HudEditor": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "InfiniteAura": {
        "Cps": 2,
        "Multiaura": true,
        "Range": 36.27934265136719,
        "enabled": false,
        "keybind": 90,
        "mob": false,
        "visible": true
    },
    "InstaBreak": {
        "enabled": false,
        "keybind": 71,
        "visible": true
    },
    "InvCleaner": {
        "Armor": false,
        "AutoSort": false,
        "Blocks": false,
        "Food": false,
        "OpenInv": false,
        "Tools": false,
        "enabled": false,
        "keybind": 116,
        "visible": true
    },
    "InventoryMove": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "InventoryViewer": {
        "Position": {
            "X": 494.0,
            "Y": 314.0
        },
        "enabled": true,
        "keybind": 0,
        "visible": true
    },
    "JavaInv": {
        "Custom Binds": true,
        "Item Animation": false,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "JavaSneak": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Jesus": {
        "Solid": true,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Jetpack": {
        "Bypass": false,
        "enabled": false,
        "keybind": 70,
        "speed": 3.0,
        "visible": true
    },
    "Keystrokes": {
        "Position": {
            "X": 2.0,
            "Y": 246.5
        },
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Killaura": {
        "Auto Weapon": false,
        "CPS": 12,
        "Death Disable": false,
        "Hit Type": 1,
        "Horizontal Range": 180.0,
        "MobAura": true,
        "Prefer Swords": false,
        "Range": 3.6573305130004883,
        "Rotation Type": 1,
        "Rotations": 1,
        "See-through attack": true,
        "Switch Delay": 15.073868751525879,
        "TargetHud": true,
        "TeamCheck": false,
        "Vertical Range": 180.0,
        "Visual Range": true,
        "Visual Range Color": {
            "Blue": 0.8231291770935059,
            "Green": 0.0,
            "HueX": 62.63072967529297,
            "PickerX": 0.0,
            "PickerY": 0.0,
            "Red": 1.0
        },
        "enabled": false,
        "keybind": 86,
        "visible": false
    },
    "MidClick": {
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "MurderTool": {
        "Esp": true,
        "Nametags": true,
        "Nametagss": false,
        "Opacity": 1.0,
        "Show Everyone": true,
        "Show Players": true,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "NameTags": {
        "Armor": true,
        "Encase Items": true,
        "Opacity": 0.3998388350009918,
        "enabled": true,
        "keybind": 89,
        "visible": false
    },
    "Nbt": {
        "Pretty Formatting": false,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "NoClip": {
        "Horizontal Speed": 0.44903382658958435,
        "Save Old POS": false,
        "Vertical Speed": 0.3333468437194824,
        "enabled": false,
        "keybind": 9,
        "visible": true
    },
    "NoFall": {
        "Type": 0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "NoFriends": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "NoHurtcam": {
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "NoPacket": {
        "enabled": false,
        "keybind": 79,
        "visible": true
    },
    "NoPaintingCrash": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "NoRender": {
        "Block Entities": false,
        "Entities": false,
        "Entity Shadows": false,
        "Fire": true,
        "Nausea": true,
        "Particles": true,
        "Weather": true,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "NoSlowDown": {
        "enabled": false,
        "keybind": 88,
        "visible": true
    },
    "NoSwing": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Nuker": {
        "auto destroy": false,
        "enabled": false,
        "keybind": 0,
        "radius": 1,
        "veinminer": false,
        "visible": true
    },
    "Offhand": {
        "Item": 0,
        "Mode": 0,
        "enabled": false,
        "keybind": 80,
        "visible": false
    },
    "Phase": {
        "Clip Distance": 1.0999999046325684,
        "Mode": 1,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Radar": {
        "Background Opacity": 0.20000000298023224,
        "Pixel Opacity": 1.0,
        "Pixel Size": 2.5,
        "Show Grid": true,
        "Size": 100,
        "Zoom": 1.0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Reach": {
        "Reach Value": 4.495028972625732,
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "Scaffold": {
        "AutoSelect": true,
        "Bypass": true,
        "Client Head Rot": false,
        "Delay MS": 83.08899688720703,
        "Down": false,
        "Extender": 0.6191549301147461,
        "Highlight": true,
        "Lock Y Axis": false,
        "Restore Old Slot": false,
        "Server Head Rot": false,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "ShulkerNesting": {
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "SkinStealer": {
        "Steal Capes": true,
        "enabled": false,
        "keybind": 76,
        "visible": true
    },
    "Spammer": {
        "bypass": false,
        "delay": 1,
        "enabled": false,
        "keybind": 75,
        "visible": true
    },
    "Speed": {
        "Type": 0,
        "enabled": false,
        "keybind": 0,
        "speed": 0.10000000149011612,
        "velocity": 2.5,
        "visible": true
    },
    "Spider": {
        "Speed": 0.44341355562210083,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "StackableItem": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Step": {
        "Mode": 0,
        "Packet (Cool)": false,
        "Reverse": false,
        "Reverse Distance": 3,
        "Smooth (Cool)": true,
        "Step Height": 1.2933411598205566,
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "Surround": {
        "Centre Player": true,
        "Disable Complete": true,
        "Swap": false,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Swing": {
        "Swings": 0,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "SwingSounds": {
        "Global Sound": true,
        "Swings": 1,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "TabGui": {
        "Font": 0,
        "Opacity": 0.800000011920929,
        "Scale": 1.0,
        "Slider": false,
        "Style": 0,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "TargetHud": {
        "Position": {
            "X": 2.0,
            "Y": 312.0
        },
        "Primary Color": {
            "Blue": 0.8174533247947693,
            "Green": 0.2874833345413208,
            "HueX": 47.63072967529297,
            "PickerX": 15.630729675292969,
            "PickerY": 0.0,
            "Red": 1.0
        },
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "Teams": {
        "enabled": false,
        "is allied": false,
        "keybind": 0,
        "same color": true,
        "visible": true
    },
    "TimeChanger": {
        "enabled": true,
        "keybind": 0,
        "modifier": 0.5537171363830566,
        "visible": false
    },
    "Timer": {
        "enabled": false,
        "keybind": 82,
        "ticks per second": 53,
        "visible": true
    },
    "ToggleSneak": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Tower": {
        "enabled": false,
        "keybind": 0,
        "motion": 0.8145470023155212,
        "visible": true
    },
    "Tracer": {
        "Color": {
            "Blue": 255.0,
            "Green": 255.0,
            "HueX": 0.0,
            "PickerX": 0.0,
            "PickerY": 0.0,
            "Red": 255.0
        },
        "Include Mobs": false,
        "enabled": false,
        "keybind": 0,
        "visible": false
    },
    "TradeUnlocker": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "TriggerBot": {
        "Delay": 1,
        "Include Mobs": false,
        "enabled": false,
        "keybind": 72,
        "visible": false
    },
    "TrueSight": {
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "VHop": {
        "Speed": 1.0,
        "Weird Friction": true,
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Velocity": {
        "Height Modifier": 0.0,
        "Linear Modifier": 0.0,
        "enabled": false,
        "keybind": 71,
        "visible": true
    },
    "ViewModel": {
        "Reset": false,
        "Rotate": true,
        "RotateAngle": 0.0,
        "RotateX": 0.10000002384185791,
        "RotateY": 0.0,
        "RotateZ": 0.0,
        "Scale": true,
        "ScaleX": 1.0,
        "ScaleY": 1.0,
        "ScaleZ": 1.0,
        "Translate": true,
        "TranslateX": 0.28252077102661133,
        "TranslateY": -0.10170197486877441,
        "TranslateZ": -0.5154801607131958,
        "enabled": true,
        "keybind": 0,
        "visible": false
    },
    "Watermark": {
        "Position": {
            "X": 369.5,
            "Y": 42.25
        },
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Waypoints": {
        "Interdimensional": true,
        "Show coordinates": true,
        "Size": 1.5999999046325684,
        "enabled": false,
        "keybind": 0,
        "list": {
            "home": {
                "dim": 0,
                "pos": {
                    "x": 3221.0,
                    "y": 70.0,
                    "z": -4150.0
                }
            }
        },
        "visible": true
    },
    "Xray": {
        "enabled": false,
        "keybind": 0,
        "visible": true
    },
    "Zoom": {
        "Smooth": true,
        "Strength": 79.14833068847656,
        "enabled": false,
        "keybind": 67,
        "visible": false
    },
    "from": "Horion",
    "prefix": ".",
    "version": "1.21.5101"
}
